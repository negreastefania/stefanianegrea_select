// De la index 0
#include<iostream>
#include<limits.h>

int V[100];
int n;
        int top=0;
using namespace std;


int main(){
    cout<<"n = ";cin>>n;
    for(int i=1;i<=n;i++){
        cout<<"V["<<i<<"] = ";
        cin>>V[i];}
    for(int i=1;i<n;i++){

        for(int j=n;j>=1;j--){
                int minim=INT_MIN;
            if(V[j--]<minim){
                minim=V[j-1];
                top=j;}}
        swap(V[i],V[top]);}
    cout<<endl<<"Sortate"<<endl;
    for(int i=1;i<=n;i++){
 //           cout << minim;
        cout<<V[i]<<" ";}
    return 1;}
